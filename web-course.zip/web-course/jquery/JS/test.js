// function saySomething(phrase) {
//   console.log("You said: " + phrase);
// }


// creating a variable to pass the string into the saysomething funtion
// the parameter is the instructions
/*const myVar = "Hello this is me learning about functions";
saySomething(myVar);*/

function getPhrase(params) {
  let l = 0;

  if (typeof params.phrase !== "undefined") {
    l = params.phrase.length;
  }

  if (typeof params.another !== "undefined") {
    l += params.another.length;
  }

  return l;
}

const p1 = "This is a really long sentence.";
const p2 = "This is a shorter sentence";
const computed = getPhrase({ phrase: "", another: p2 });
console.log(computed);
