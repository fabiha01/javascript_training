
/*
function alertMe() {
  alert("Me")
} */



$(document).ready(function () {

  function printThis(el) {
    if ($(this).text()) {
      console.log($(this).text());
    } else {
      console.log($(this).val());
    }

  }

  const el = document.getElementById('text');


  $('[data-trigger="dropdown"]').on('mouseenter', function () {

    // fading in and out for the menu on the webpage
    const submenu = $(this).parent().find('.submenu');
    submenu.fadeIn(300);

    $('.profile-menu').on('mouseleave', function () {
      submenu.fadeOut(300);
    })
  });

  $('input').focusin(printThis);

  // any property in css should work on here
  // documentation relating to jQuery should
  // explain what you can use in this object
  $('input').css({
    background: '#ff2',
    padding: '10px',
    borderColor: '#000',
    backgroundSize: 'cover'
  });


});
 
