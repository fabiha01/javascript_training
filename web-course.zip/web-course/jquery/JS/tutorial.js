
// this function loops through, using the lowest number in
// array and finds the missing number
/*function missingno(numbers) {
  let missing = -1;

  for (let i = 0; i <= numbers.length; i++) {
    if (numbers.indexOf(i) === -1) {
      missing = i;
    }
  }

  return missing;

}

const numbers = [0, 6, 7, 10, 8, 5, 4, 1, 3, 9];

console.log(missingno(numbers)) */

// writing classes and extending classes

// class Animal {
//   constructor(name, height, weight) {
//     console.log("Created Animal named " + name);
//     this.name = name;
//     this.height = height;
//     this.weight = weight;
//   }

//   nameLength() {
//     return this.name.length;
//   }
// }

// class Dog extends Animal {
//   constructor(name, height, weight, barkVolume, leashColour, speed) {
//     super (name, height, weight);

//     this.barkVolume = barkVolume;
//     this.leashColour = leashColour;
//     this.speed = speed;
//   }

//   bark() {
//     if(this.barkVolume > 50) {
//       console.log(this.name, "barks loudly! (volume: ", this.barkVolume, ")");
//     } else {
//       console.log(this.name, "barks timidly. (volume: ", this.barkVolume, ")");
//     }
//   }
// }

// class Fish extends Animal {
//   constructor(name, height, weight, swimSpeed) {
//     super (name, height, weight);
//     this.swimSpeed = swimSpeed;
//   }

//   swim(chaserSpeed) {
//     if (this.swimSpeed > 50) {
//       console.log(this.name, "swims around quickly! (speed: ", this.swimSpeed + ")");
//     } else {
//       console.log(this.name, "swims around slowly. (speed: ", this.swimSpeed, ")");
//     }

//     if (this.swimSpeed > chaserSpeed) {
//       console.log(this.name, "got away!")
//     } else {
//       console.log(this.name, "was caught!")
//     }
//   }
// }

// const king = new Dog("King", 45, 92, 72, "Red", 52);
// const goldie = new Fish("Goldie", 2, 0.02, 40);

// king.bark();
// goldie.swim(king.speed);
