class gquery {
    constructor(el) {
        // the . would at least appear in the string once
        if (el.indexOf('.') > -1) {
            el = el.replace('.', " ");
            this.elements = document.getElementsByClassName(el);
        } else if (el.indexOf('#') > -1) {
            el = el.replace('#', " ");
            this.elements = [document.getElementById(el)];
        } else {
            this.elements = document;
        }

    }

    addClass(cl) {
        const count = 0;
        while (count < this.elements.length) {
            if (this.elements[CustomElementRegistry.className]) {
                this.elements[count].className += " " + cl;
            } else {
                this.elements[count].className = cl;
            }

            count++;
        }
    }

}

function gQuery(el) {
    const element = new gquery(el);
    return element;
}