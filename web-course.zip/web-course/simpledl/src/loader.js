s = document.createElement("script");
s.src = chrome.extension.getURL("src/youtubedl.js");

(document.head || document.documentElement).appendChild(s);

window.addEventListener("message", function(e) {
    console.log("download:", e);
    const ext = "html";
    const fn = e.data.name + "." + ext;
    console.log(fn);

    chrome.runtime.sendMessage({name:fn, url: e.data.url}, function(res) {
        console.log(res);
    });
    // chrome.downloads.download({url: e.data.url, filename: fn});
});