
function downloadVideo() {
    console.log('Download this video');
    let dl = document.getElementById('videoDownloadDropdown');
    if (dl.className.indexOf("shown") > -1) {
        dl.className = dl.className.replace("shown", "");
    } else {
        dl.className += "shown";
    }
}

function downloadURI(event) {
    event.preventDefault();
    event.stopPropagation();


    const url = event.currentTarget.getAttribute("href");
    const name = document.getElementsByTagName("title")[0].innerText;
    const dataType = event.currentTarget.getAttribute("data-type");
    const data = {url: url, name: name, sender: "YTDL", type: dataType}; 

    window.postMessage(data, '*');

    return false;
}

const videoUrls = window.ytplayer.config.args.loaderUrl.split(',').map(function (item) {
    return item.split('&').reduce(function (pre, curr) {
        console.log(pre, curr);
        curr = curr.split('=');
        return Object.assign(pre, { [curr[0]]: decodeURIComponent(curr[1]) });
    }, {});
});
console.log("Our extension has loaded", videoUrls);

const container = document.getElementById('flex');
const btn = document.createElement('button');
btn.className = 'style-scope ytd-toggle-button-renderer style-text';
btn.setAttribute("role", "button");
btn.id = "downloadVideo";
btn.innerText = "Download";

const dropdown = document.createElement("div");
dropdown.id = "videoDownloadDropdown";
container.appendChild(dropdown);
const droplist = document.createElement('ul');
dropdown.appendChild(droplist);

container.appendChild(btn);

for (i in videoUrls) {
    const item = document.createElement('a');
     // const ext = videoUrls[i]["type"].split("/")[1].split(";")[0];
    item.innerText = videoUrls[i]["https://www.youtube.com/watch?v"];
    // item.setAttribute("href", videoUrls[i]["url"]);
    item.setAttribute("href", "https://www.google.com");
    item.setAttribute("target", "_blank");
    item.setAttribute("data-type", videoUrls[i]["type"]);
    item.addEventListener("click", downloadURI);
    droplist.appendChild(item);
}
btn.addEventListener("click", downloadVideo);

