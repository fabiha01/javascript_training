chrome.runtime.onMessage.addListener(function(request, sender, callback) {
    console.log("reveived", request, sender, callback);

    chrome.downloads.download({url: request.url, filename: request.name.replace('?', '')});
});